/**
 * @file refinement.cc
 * @brief implementation of splitting of reference entities according to
 * refinement patterns
 */

#include "refinement.h"

namespace lf::refinement {}  // namespace lf::refinement
