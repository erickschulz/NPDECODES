/** @file mesh_interface.cc
 * @brief Implements the diagnostic output function for meshes
 */

#include "mesh_interface.h"
#include <lf/geometry/geometry.h>

namespace lf::mesh {}  // namespace lf::mesh
