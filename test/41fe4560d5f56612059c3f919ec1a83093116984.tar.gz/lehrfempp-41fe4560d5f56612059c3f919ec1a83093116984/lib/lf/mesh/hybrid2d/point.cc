/**
 * @brief No non-inline implementation for Point class
 */

namespace lf::mesh::hybrid2d {}
