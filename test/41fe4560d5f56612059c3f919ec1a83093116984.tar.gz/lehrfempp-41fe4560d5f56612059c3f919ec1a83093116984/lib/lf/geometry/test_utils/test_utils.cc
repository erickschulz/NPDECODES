/**
 * @file
 * @brief Empty shell
 * @author Anian Ruoss
 * @date   2019-03-04 23:00:17
 * @copyright MIT License
 */

namespace lf::geometry::test_utils {}
