/** @file geometry.cc
 * @brief Empty shell
 */

#include "geometry.h"

namespace lf::geometry {}  // namespace lf::geometry
