/**
 * @file
 * @brief Sample header that declares some additional options.
 * @author Raffael Casagrande
 * @date   2019-03-24 06:02:09
 * @copyright MIT License
 */

#ifndef __af2b7bfc148e40e1a9e971f522375148
#define __af2b7bfc148e40e1a9e971f522375148
#include "lf/base/comm.h"

#endif  // __af2b7bfc148e40e1a9e971f522375148
