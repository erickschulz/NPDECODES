# LehrFEM++ examples

The folders in this directory contain demonstration codes for various capabilities of
LehrFEM++ that spawn simple executables. The source codes should be lucid enough to be
useful for learners of LehrFEM++. 

Note that the `lecturedemos` folder contains source codes directly related to sample codes
discussed in the ETH Zurich course "Numerical Methods for Partial Differential Equations".
