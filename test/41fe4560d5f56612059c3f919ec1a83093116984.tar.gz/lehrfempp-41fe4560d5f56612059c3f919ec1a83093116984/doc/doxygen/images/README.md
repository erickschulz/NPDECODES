## Pictures illustrating refinement in sunfolders

 Pictures were drawn by Gina Magnussen.

All files exist in three versions: A -.svg, a -.pdf and a -.png file. 

The naming of these is similar to what is written in the refinement note, 
and the number in the file name indicates anchor edge. 
For files with two numbers the first indicates anchor edge, 
and the second number tells you which edge one of the refinement edges splits. 
This is to tell apart different trisect refinement patterns that have 
the same anchor edge.)

 
